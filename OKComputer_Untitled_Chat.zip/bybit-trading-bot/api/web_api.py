"""
Web API for Trading Bot Dashboard
=================================
Flask-based REST API and WebSocket for real-time updates
"""

import json
import threading
import time
from datetime import datetime
from flask import Flask, jsonify, request
nfrom flask_cors import CORS
from flask_socketio import SocketIO, emit

from config.config import TradingConfig
from bot.bybit_trader import BybitTrader

# Global variables
trader: BybitTrader = None
bot_thread: threading.Thread = None

# Flask app
app = Flask(__name__)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Background update thread
def emit_updates():
    """Emit real-time updates via WebSocket"""
    while True:
        if trader:
            try:
                status = trader.get_status()
                socketio.emit('status_update', status)
            except Exception as e:
                print(f"Error emitting update: {e}")
        time.sleep(5)  # Update every 5 seconds


# API Routes
@app.route('/api/status', methods=['GET'])
def get_status():
    """Get current bot status"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    return jsonify(trader.get_status())


@app.route('/api/account', methods=['GET'])
def get_account():
    """Get account information"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    account = trader.get_account_info()
    return jsonify({
        'total_equity': account.total_equity,
        'available_balance': account.available_balance,
        'margin_balance': account.margin_balance,
        'unrealized_pnl': account.unrealized_pnl
    })


@app.route('/api/positions', methods=['GET'])
def get_positions():
    """Get open positions"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    positions = trader.get_positions()
    return jsonify([{
        'symbol': p.symbol,
        'side': p.side,
        'size': p.size,
        'entry_price': p.entry_price,
        'leverage': p.leverage,
        'stop_loss': p.stop_loss,
        'take_profit': p.take_profit,
        'unrealized_pnl': p.unrealized_pnl
    } for p in positions])


@app.route('/api/positions/<symbol>/close', methods=['POST'])
def close_position(symbol):
    """Close a specific position"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    success = trader.close_position(symbol)
    return jsonify({'success': success})


@app.route('/api/orders', methods=['GET'])
def get_orders():
    """Get order history"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    return jsonify(trader.order_history[-50:])  # Last 50 orders


@app.route('/api/market/<symbol>', methods=['GET'])
def get_market_data(symbol):
    """Get market data for a symbol"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    df = trader.get_klines(symbol, limit=100)
    if df.empty:
        return jsonify({'error': 'No data available'}), 404
    
    return jsonify({
        'symbol': symbol,
        'candles': df.to_dict('records'),
        'latest_price': float(df['close'].iloc[-1]),
        'change_24h': float((df['close'].iloc[-1] - df['close'].iloc[-24]) / df['close'].iloc[-24] * 100) if len(df) >= 24 else 0
    })


@app.route('/api/signals/<symbol>', methods=['GET'])
def get_signals(symbol):
    """Get trading signals for a symbol"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    df = trader.get_klines(symbol)
    if df.empty:
        return jsonify({'error': 'No data available'}), 404
    
    signals = trader.strategy_manager.get_all_signals(df)
    
    return jsonify({
        'symbol': symbol,
        'signals': {
            name: {
                'signal': sig.signal.value,
                'confidence': sig.confidence,
                'reason': sig.reason,
                'entry_price': sig.entry_price,
                'stop_loss': sig.stop_loss,
                'take_profit': sig.take_profit,
                'indicators': sig.indicators
            }
            for name, sig in signals.items()
        }
    })


@app.route('/api/risk', methods=['GET'])
def get_risk_report():
    """Get risk management report"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    return jsonify(trader.risk_manager.get_risk_report())


@app.route('/api/bot/start', methods=['POST'])
def start_bot():
    """Start the trading bot"""
    global bot_thread, trader
    
    if trader and trader.running:
        return jsonify({'error': 'Bot already running'}), 400
    
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    def run_bot():
        trader.start()
    
    bot_thread = threading.Thread(target=run_bot, daemon=True)
    bot_thread.start()
    
    return jsonify({'success': True, 'message': 'Bot started'})


@app.route('/api/bot/stop', methods=['POST'])
def stop_bot():
    """Stop the trading bot"""
    global trader
    
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    trader.stop()
    return jsonify({'success': True, 'message': 'Bot stopped'})


@app.route('/api/bot/config', methods=['GET'])
def get_config():
    """Get current configuration"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    config = trader.config
    return jsonify({
        'testnet': config.testnet,
        'trading_mode': config.trading_mode.value,
        'trading_pairs': config.trading_pairs,
        'strategy': config.strategy.strategy_type.value,
        'risk': {
            'max_risk_per_trade': config.risk.max_account_risk_per_trade,
            'max_daily_loss': config.risk.max_daily_loss,
            'max_positions': config.risk.max_concurrent_positions,
            'max_leverage': config.risk.max_leverage,
            'use_trailing_stop': config.risk.use_trailing_stop
        }
    })


@app.route('/api/bot/config', methods=['POST'])
def update_config():
    """Update configuration (requires restart)"""
    # Implementation for updating config
    return jsonify({'success': False, 'message': 'Restart required to apply changes'})


@app.route('/api/trade/manual', methods=['POST'])
def manual_trade():
    """Execute a manual trade"""
    if not trader:
        return jsonify({'error': 'Bot not initialized'}), 503
    
    data = request.json
    symbol = data.get('symbol')
    side = data.get('side')  # Buy or Sell
    qty = data.get('qty')
    
    if not all([symbol, side, qty]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    order_id = trader.place_order(
        symbol=symbol,
        side=side,
        qty=float(qty),
        order_type="Market"
    )
    
    if order_id:
        return jsonify({'success': True, 'order_id': order_id})
    else:
        return jsonify({'error': 'Order failed'}), 500


# WebSocket events
@socketio.on('connect')
def handle_connect():
    print('Client connected')
    emit('connected', {'data': 'Connected to trading bot'})


@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')


def start_dashboard(config: TradingConfig, host='0.0.0.0', port=5000):
    """Start the web dashboard"""
    global trader
    
    # Initialize trader
    trader = BybitTrader(config)
    
    # Start background update thread
    update_thread = threading.Thread(target=emit_updates, daemon=True)
    update_thread.start()
    
    print(f"=" * 60)
    print(f"Trading Bot Dashboard")
    print(f"=" * 60)
    print(f"API: http://{host}:{port}/api")
    print(f"WebSocket: ws://{host}:{port}")
    print(f"=" * 60)
    
    # Run Flask-SocketIO
    socketio.run(app, host=host, port=port, debug=False)


if __name__ == '__main__':
    # For standalone testing
    from config.config import TradingConfig
    config = TradingConfig()
    config.testnet = True
    start_dashboard(config)