import { useState, useEffect, useCallback } from 'react'
import { 
  Activity, TrendingUp, TrendingDown, Wallet, 
  Play, Pause, Settings, Bell, BarChart3, 
  Shield, Target, Zap, DollarSign, Clock,
  AlertTriangle, CheckCircle, XCircle, RefreshCw
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import './App.css'

// Types
interface AccountInfo {
  total_equity: number
  available_balance: number
  margin_balance: number
  unrealized_pnl: number
}

interface Position {
  symbol: string
  side: string
  size: number
  entry_price: number
  leverage: number
  stop_loss: number
  take_profit: number
  unrealized_pnl: number
}

interface RiskReport {
  daily_pnl: number
  trades_today: number
  win_rate: number
  avg_win: number
  avg_loss: number
  profit_factor: number
  risk_score: number
}

interface BotStatus {
  running: boolean
  testnet: boolean
  last_update: string
  account: AccountInfo
  positions: Position[]
  risk: RiskReport
  trading_pairs: string[]
  strategy: string
}

interface Signal {
  signal: string
  confidence: number
  reason: string
  entry_price: number
  stop_loss: number
  take_profit: number
  indicators: Record<string, number>
}

const API_BASE = 'http://localhost:5000/api'

function App() {
  const [status, setStatus] = useState<BotStatus | null>(null)
  const [signals, setSignals] = useState<Record<string, Signal>>({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT')
  const [wsConnected, setWsConnected] = useState(false)

  // Fetch bot status
  const fetchStatus = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE}/status`)
      if (response.ok) {
        const data = await response.json()
        setStatus(data)
        setError(null)
      } else {
        setError('Failed to fetch bot status')
      }
    } catch (err) {
      setError('Cannot connect to trading bot API')
    } finally {
      setLoading(false)
    }
  }, [])

  // Fetch signals
  const fetchSignals = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE}/signals/${selectedSymbol}`)
      if (response.ok) {
        const data = await response.json()
        setSignals(data.signals || {})
      }
    } catch (err) {
      console.error('Failed to fetch signals:', err)
    }
  }, [selectedSymbol])

  // Control bot
  const controlBot = async (action: 'start' | 'stop') => {
    try {
      const response = await fetch(`${API_BASE}/bot/${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      })
      if (response.ok) {
        fetchStatus()
      }
    } catch (err) {
      setError(`Failed to ${action} bot`)
    }
  }

  // Close position
  const closePosition = async (symbol: string) => {
    try {
      const response = await fetch(`${API_BASE}/positions/${symbol}/close`, {
        method: 'POST'
      })
      if (response.ok) {
        fetchStatus()
      }
    } catch (err) {
      setError(`Failed to close position for ${symbol}`)
    }
  }

  // Initial load and polling
  useEffect(() => {
    fetchStatus()
    fetchSignals()
    
    const interval = setInterval(() => {
      fetchStatus()
    }, 5000)

    return () => clearInterval(interval)
  }, [fetchStatus, fetchSignals])

  // WebSocket connection
  useEffect(() => {
    const ws = new WebSocket('ws://localhost:5000')
    
    ws.onopen = () => {
      setWsConnected(true)
    }
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data)
      if (data.status_update) {
        setStatus(data.status_update)
      }
    }
    
    ws.onclose = () => {
      setWsConnected(false)
    }
    
    return () => ws.close()
  }, [])

  // Format number
  const formatNumber = (num: number, decimals = 2) => {
    if (num === undefined || num === null) return '-'
    return num.toLocaleString('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    })
  }

  // Format percentage
  const formatPct = (num: number) => {
    if (num === undefined || num === null) return '-'
    const prefix = num >= 0 ? '+' : ''
    return `${prefix}${formatNumber(num)}%`
  }

  // Get signal color
  const getSignalColor = (signal: string) => {
    if (signal === 'buy') return 'text-green-500'
    if (signal === 'sell') return 'text-red-500'
    return 'text-gray-500'
  }

  // Get signal badge
  const getSignalBadge = (signal: string) => {
    if (signal === 'buy') return <Badge className="bg-green-500">BUY</Badge>
    if (signal === 'sell') return <Badge className="bg-red-500">SELL</Badge>
    return <Badge variant="secondary">HOLD</Badge>
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-16 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Activity className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Bybit Trading Bot</h1>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <span className={`w-2 h-2 rounded-full ${wsConnected ? 'bg-green-500' : 'bg-red-500'}`} />
                    {wsConnected ? 'Connected' : 'Disconnected'}
                  </span>
                  {status && (
                    <>
                      <span>•</span>
                      <Badge variant={status.testnet ? 'secondary' : 'destructive'}>
                        {status.testnet ? 'Testnet' : 'LIVE'}
                      </Badge>
                    </>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={fetchStatus}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              
              {status && (
                <Button
                  size="sm"
                  onClick={() => controlBot(status.running ? 'stop' : 'start')}
                  variant={status.running ? 'destructive' : 'default'}
                >
                  {status.running ? (
                    <><Pause className="w-4 h-4 mr-2" /> Stop</>
                  ) : (
                    <><Play className="w-4 h-4 mr-2" /> Start</>
                  )}
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-6">
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertTriangle className="w-4 h-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {!status && !error && (
          <Alert className="mb-6">
            <AlertDescription>
              Cannot connect to trading bot. Make sure the bot is running with <code>--dashboard</code> flag.
            </AlertDescription>
          </Alert>
        )}

        {status && (
          <>
            {/* Account Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Total Equity
                  </CardTitle>
                  <Wallet className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ${formatNumber(status.account.total_equity)}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Available: ${formatNumber(status.account.available_balance)}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Unrealized P&L
                  </CardTitle>
                  <TrendingUp className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${status.account.unrealized_pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {status.account.unrealized_pnl >= 0 ? '+' : ''}{formatNumber(status.account.unrealized_pnl)}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Open positions
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Daily P&L
                  </CardTitle>
                  <DollarSign className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${status.risk.daily_pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {status.risk.daily_pnl >= 0 ? '+' : ''}${formatNumber(status.risk.daily_pnl)}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {status.risk.trades_today} trades today
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Win Rate
                  </CardTitle>
                  <Target className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatNumber(status.risk.win_rate)}%
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Profit Factor: {formatNumber(status.risk.profit_factor)}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Main Dashboard Tabs */}
            <Tabs defaultValue="positions" className="space-y-4">
              <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
                <TabsTrigger value="positions">Positions</TabsTrigger>
                <TabsTrigger value="signals">Signals</TabsTrigger>
                <TabsTrigger value="risk">Risk Management</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>

              {/* Positions Tab */}
              <TabsContent value="positions" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5" />
                      Open Positions ({status.positions.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {status.positions.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <p>No open positions</p>
                        <p className="text-sm">The bot will open positions when signals are generated</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {status.positions.map((position) => (
                          <div
                            key={position.symbol}
                            className="flex items-center justify-between p-4 border rounded-lg"
                          >
                            <div className="flex items-center gap-4">
                              <div className={`p-2 rounded-lg ${
                                position.side === 'Buy' ? 'bg-green-500/10' : 'bg-red-500/10'
                              }`}>
                                {position.side === 'Buy' ? (
                                  <TrendingUp className={`w-5 h-5 ${
                                    position.side === 'Buy' ? 'text-green-500' : 'text-red-500'
                                  }`} />
                                ) : (
                                  <TrendingDown className="w-5 h-5 text-red-500" />
                                )}
                              </div>
                              <div>
                                <p className="font-semibold">{position.symbol}</p>
                                <p className="text-sm text-muted-foreground">
                                  {position.side} • {position.leverage}x • {formatNumber(position.size, 4)}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-8">
                              <div className="text-right">
                                <p className="text-sm text-muted-foreground">Entry</p>
                                <p className="font-medium">${formatNumber(position.entry_price)}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-sm text-muted-foreground">P&L</p>
                                <p className={`font-medium ${position.unrealized_pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                                  {position.unrealized_pnl >= 0 ? '+' : ''}{formatNumber(position.unrealized_pnl)}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="text-sm text-muted-foreground">SL / TP</p>
                                <p className="font-medium text-xs">
                                  ${formatNumber(position.stop_loss)} / ${formatNumber(position.take_profit)}
                                </p>
                              </div>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => closePosition(position.symbol)}
                              >
                                Close
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Signals Tab */}
              <TabsContent value="signals" className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <Zap className="w-5 h-5" />
                        Trading Signals
                      </CardTitle>
                      <div className="flex gap-2">
                        {status.trading_pairs.map((pair) => (
                          <Button
                            key={pair}
                            variant={selectedSymbol === pair ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setSelectedSymbol(pair)}
                          >
                            {pair}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {Object.entries(signals).map(([strategy, signal]) => (
                        <div
                          key={strategy}
                          className="p-4 border rounded-lg"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <h3 className="font-semibold capitalize">{strategy.replace('_', ' ')}</h3>
                              {getSignalBadge(signal.signal)}
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-muted-foreground">Confidence:</span>
                              <Progress value={signal.confidence * 100} className="w-24" />
                              <span className="text-sm font-medium">{formatNumber(signal.confidence * 100)}%</span>
                            </div>
                          </div>
                          
                          <p className="text-sm text-muted-foreground mb-3">{signal.reason}</p>
                          
                          {signal.signal !== 'hold' && (
                            <div className="grid grid-cols-3 gap-4 text-sm">
                              <div>
                                <span className="text-muted-foreground">Entry:</span>
                                <span className="ml-2 font-medium">${formatNumber(signal.entry_price)}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Stop Loss:</span>
                                <span className="ml-2 font-medium text-red-500">${formatNumber(signal.stop_loss)}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Take Profit:</span>
                                <span className="ml-2 font-medium text-green-500">${formatNumber(signal.take_profit)}</span>
                              </div>
                            </div>
                          )}
                          
                          {signal.indicators && (
                            <div className="mt-3 pt-3 border-t">
                              <div className="flex flex-wrap gap-2">
                                {Object.entries(signal.indicators).map(([key, value]) => (
                                  <Badge key={key} variant="outline" className="text-xs">
                                    {key}: {typeof value === 'boolean' ? (value ? 'Yes' : 'No') : formatNumber(value)}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Risk Tab */}
              <TabsContent value="risk" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5" />
                        Risk Metrics
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Risk Score</span>
                        <div className="flex items-center gap-2">
                          <Progress 
                            value={status.risk.risk_score * 100} 
                            className={`w-24 ${
                              status.risk.risk_score > 0.7 ? 'bg-red-500' : 
                              status.risk.risk_score > 0.4 ? 'bg-yellow-500' : 'bg-green-500'
                            }`}
                          />
                          <span className={`font-medium ${
                            status.risk.risk_score > 0.7 ? 'text-red-500' : 
                            status.risk.risk_score > 0.4 ? 'text-yellow-500' : 'text-green-500'
                          }`}>
                            {formatNumber(status.risk.risk_score * 100)}%
                          </span>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Daily P&L</span>
                        <span className={status.risk.daily_pnl >= 0 ? 'text-green-500' : 'text-red-500'}>
                          {status.risk.daily_pnl >= 0 ? '+' : ''}${formatNumber(status.risk.daily_pnl)}
                        </span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Trades Today</span>
                        <span className="font-medium">{status.risk.trades_today}</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Win Rate</span>
                        <span className="font-medium">{formatNumber(status.risk.win_rate)}%</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Average Win</span>
                        <span className="text-green-500 font-medium">${formatNumber(status.risk.avg_win)}</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Average Loss</span>
                        <span className="text-red-500 font-medium">${formatNumber(status.risk.avg_loss)}</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Profit Factor</span>
                        <span className={`font-medium ${status.risk.profit_factor > 1 ? 'text-green-500' : 'text-red-500'}`}>
                          {formatNumber(status.risk.profit_factor)}
                        </span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5" />
                        Risk Limits
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="p-3 bg-green-500/10 rounded-lg">
                        <div className="flex items-center gap-2 text-green-600 mb-1">
                          <CheckCircle className="w-4 h-4" />
                          <span className="font-medium">Daily Loss Limit</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Bot will stop if daily loss exceeds 5%
                        </p>
                      </div>
                      
                      <div className="p-3 bg-green-500/10 rounded-lg">
                        <div className="flex items-center gap-2 text-green-600 mb-1">
                          <CheckCircle className="w-4 h-4" />
                          <span className="font-medium">Max Risk Per Trade</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Maximum 2% of account per trade
                        </p>
                      </div>
                      
                      <div className="p-3 bg-green-500/10 rounded-lg">
                        <div className="flex items-center gap-2 text-green-600 mb-1">
                          <CheckCircle className="w-4 h-4" />
                          <span className="font-medium">Trailing Stops</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Enabled to protect profits
                        </p>
                      </div>
                      
                      <div className="p-3 bg-green-500/10 rounded-lg">
                        <div className="flex items-center gap-2 text-green-600 mb-1">
                          <CheckCircle className="w-4 h-4" />
                          <span className="font-medium">Position Limits</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Max 3 concurrent positions
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Settings Tab */}
              <TabsContent value="settings" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="w-5 h-5" />
                      Bot Configuration
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm text-muted-foreground">Trading Mode</span>
                        <p className="font-medium">{status.strategy.replace('_', ' ').toUpperCase()}</p>
                      </div>
                      <div>
                        <span className="text-sm text-muted-foreground">Network</span>
                        <p className="font-medium">{status.testnet ? 'Testnet' : 'Mainnet'}</p>
                      </div>
                      <div>
                        <span className="text-sm text-muted-foreground">Trading Pairs</span>
                        <p className="font-medium">{status.trading_pairs.join(', ')}</p>
                      </div>
                      <div>
                        <span className="text-sm text-muted-foreground">Last Update</span>
                        <p className="font-medium">
                          {new Date(status.last_update).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Bot Status</p>
                        <p className="text-sm text-muted-foreground">
                          {status.running ? 'Active and trading' : 'Stopped'}
                        </p>
                      </div>
                      <Badge variant={status.running ? 'default' : 'secondary'}>
                        {status.running ? 'Running' : 'Stopped'}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t mt-8">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <p>Bybit Trading Bot • Built with advanced risk management</p>
            <p>Last updated: {new Date().toLocaleTimeString()}</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App