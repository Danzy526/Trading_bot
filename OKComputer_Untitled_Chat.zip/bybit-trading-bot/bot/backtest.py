"""
Backtesting Module
=================
Test trading strategies on historical data
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from dataclasses import dataclass
from datetime import datetime
from loguru import logger

from .strategies import StrategyManager, TradeSignal, SignalType
from config.config import TradingConfig

@dataclass
class Trade:
    """Backtest trade record"""
    entry_date: datetime
    exit_date: datetime
    symbol: str
    side: str
    entry_price: float
    exit_price: float
    size: float
    pnl: float
    pnl_pct: float
    reason: str

@dataclass
class BacktestResult:
    """Backtest results"""
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    total_pnl: float
    total_pnl_pct: float
    avg_trade: float
    avg_win: float
    avg_loss: float
    profit_factor: float
    max_drawdown: float
    max_drawdown_pct: float
    sharpe_ratio: float
    trades: List[Trade]
    equity_curve: pd.DataFrame

class Backtester:
    """Strategy backtesting engine"""
    
    def __init__(self, config: TradingConfig):
        self.config = config
        self.strategy_manager = StrategyManager(config)
        self.initial_balance = 10000.0  # Default backtest balance
        self.commission = 0.0006  # 0.06% per trade (Bybit taker fee)
        
    def run_backtest(
        self,
        df: pd.DataFrame,
        symbol: str,
        strategy_name: str = None
    ) -> BacktestResult:
        """
        Run backtest on historical data
        
        Args:
            df: DataFrame with OHLCV data
            symbol: Trading pair symbol
            strategy_name: Strategy to test (None for active strategy)
        
        Returns:
            BacktestResult with performance metrics
        """
        if df.empty or len(df) < 50:
            raise ValueError("Insufficient data for backtest")
        
        # Initialize tracking variables
        balance = self.initial_balance
        equity_curve = []
        trades = []
        position = None
        
        # Iterate through data
        for i in range(50, len(df)):
            current_data = df.iloc[:i+1]
            current_bar = df.iloc[i]
            
            # Get signal
            if strategy_name:
                signal = self.strategy_manager.get_signal(current_data, strategy_name)
            else:
                signal = self.strategy_manager.get_signal(current_data)
            
            # Record equity
            equity = balance
            if position:
                unrealized_pnl = self._calculate_unrealized_pnl(
                    position, current_bar['close']
                )
                equity += unrealized_pnl
            
            equity_curve.append({
                'timestamp': current_bar['timestamp'],
                'equity': equity,
                'balance': balance
            })
            
            # Check for exit if in position
            if position:
                exit_price, exit_reason = self._check_exit(
                    position, current_bar, signal
                )
                
                if exit_price:
                    # Close position
                    trade = self._close_position(
                        position, current_bar['timestamp'],
                        exit_price, exit_reason
                    )
                    trades.append(trade)
                    balance += trade.pnl
                    position = None
            
            # Check for entry if not in position
            elif signal.signal in [SignalType.BUY, SignalType.SELL]:
                position = self._open_position(
                    signal, current_bar, balance, symbol
                )
        
        # Close any open position at the end
        if position:
            final_price = df['close'].iloc[-1]
            trade = self._close_position(
                position, df['timestamp'].iloc[-1],
                final_price, "End of backtest"
            )
            trades.append(trade)
            balance += trade.pnl
        
        # Calculate results
        return self._calculate_results(trades, equity_curve, balance)
    
    def _open_position(
        self,
        signal: TradeSignal,
        bar: pd.Series,
        balance: float,
        symbol: str
    ) -> Dict:
        """Open a new position"""
        entry_price = signal.entry_price or bar['close']
        stop_loss = signal.stop_loss or (entry_price * 0.98)
        take_profit = signal.take_profit or (entry_price * 1.04)
        
        # Calculate position size (risk 2% per trade)
        risk_amount = balance * 0.02
        price_risk = abs(entry_price - stop_loss)
        position_size = risk_amount / price_risk
        
        # Apply leverage for perpetual
        if self.config.trading_mode.value == "linear":
            position_size *= self.config.risk.default_leverage
        
        return {
            'entry_date': bar['timestamp'],
            'symbol': symbol,
            'side': 'long' if signal.signal == SignalType.BUY else 'short',
            'entry_price': entry_price,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'size': position_size,
            'signal_confidence': signal.confidence
        }
    
    def _check_exit(
        self,
        position: Dict,
        bar: pd.Series,
        signal: TradeSignal
    ) -> Tuple[float, str]:
        """Check if position should be closed"""
        high = bar['high']
        low = bar['low']
        close = bar['close']
        
        # Check stop loss
        if position['side'] == 'long':
            if low <= position['stop_loss']:
                return position['stop_loss'], "Stop Loss"
            if high >= position['take_profit']:
                return position['take_profit'], "Take Profit"
            # Exit on opposite signal
            if signal.signal == SignalType.SELL:
                return close, "Signal Reversal"
        
        else:  # short
            if high >= position['stop_loss']:
                return position['stop_loss'], "Stop Loss"
            if low <= position['take_profit']:
                return position['take_profit'], "Take Profit"
            # Exit on opposite signal
            if signal.signal == SignalType.BUY:
                return close, "Signal Reversal"
        
        return None, ""
    
    def _close_position(
        self,
        position: Dict,
        exit_date: datetime,
        exit_price: float,
        reason: str
    ) -> Trade:
        """Close position and calculate P&L"""
        if position['side'] == 'long':
            pnl = (exit_price - position['entry_price']) * position['size']
            pnl_pct = (exit_price - position['entry_price']) / position['entry_price'] * 100
        else:  # short
            pnl = (position['entry_price'] - exit_price) * position['size']
            pnl_pct = (position['entry_price'] - exit_price) / position['entry_price'] * 100
        
        # Subtract commission (entry + exit)
        commission = (position['entry_price'] + exit_price) * position['size'] * self.commission
        pnl -= commission
        
        return Trade(
            entry_date=position['entry_date'],
            exit_date=exit_date,
            symbol=position['symbol'],
            side=position['side'],
            entry_price=position['entry_price'],
            exit_price=exit_price,
            size=position['size'],
            pnl=pnl,
            pnl_pct=pnl_pct,
            reason=reason
        )
    
    def _calculate_unrealized_pnl(self, position: Dict, current_price: float) -> float:
        """Calculate unrealized P&L"""
        if position['side'] == 'long':
            return (current_price - position['entry_price']) * position['size']
        else:
            return (position['entry_price'] - current_price) * position['size']
    
    def _calculate_results(
        self,
        trades: List[Trade],
        equity_curve: List[Dict],
        final_balance: float
    ) -> BacktestResult:
        """Calculate backtest performance metrics"""
        if not trades:
            return BacktestResult(
                total_trades=0,
                winning_trades=0,
                losing_trades=0,
                win_rate=0.0,
                total_pnl=0.0,
                total_pnl_pct=0.0,
                avg_trade=0.0,
                avg_win=0.0,
                avg_loss=0.0,
                profit_factor=0.0,
                max_drawdown=0.0,
                max_drawdown_pct=0.0,
                sharpe_ratio=0.0,
                trades=[],
                equity_curve=pd.DataFrame()
            )
        
        # Basic stats
        total_trades = len(trades)
        winning_trades = sum(1 for t in trades if t.pnl > 0)
        losing_trades = total_trades - winning_trades
        win_rate = winning_trades / total_trades * 100
        
        # P&L stats
        total_pnl = sum(t.pnl for t in trades)
        total_pnl_pct = total_pnl / self.initial_balance * 100
        avg_trade = total_pnl / total_trades
        
        wins = [t.pnl for t in trades if t.pnl > 0]
        losses = [abs(t.pnl) for t in trades if t.pnl <= 0]
        
        avg_win = np.mean(wins) if wins else 0
        avg_loss = np.mean(losses) if losses else 0
        
        # Profit factor
        gross_profit = sum(wins)
        gross_loss = sum(losses)
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
        
        # Max drawdown
        equity_df = pd.DataFrame(equity_curve)
        if not equity_df.empty:
            equity_df['peak'] = equity_df['equity'].cummax()
            equity_df['drawdown'] = equity_df['equity'] - equity_df['peak']
            equity_df['drawdown_pct'] = equity_df['drawdown'] / equity_df['peak'] * 100
            
            max_drawdown = equity_df['drawdown'].min()
            max_drawdown_pct = equity_df['drawdown_pct'].min()
            
            # Sharpe ratio (assuming risk-free rate of 0)
            returns = equity_df['equity'].pct_change().dropna()
            sharpe_ratio = np.sqrt(252) * returns.mean() / returns.std() if len(returns) > 1 else 0
        else:
            max_drawdown = 0
            max_drawdown_pct = 0
            sharpe_ratio = 0
        
        return BacktestResult(
            total_trades=total_trades,
            winning_trades=winning_trades,
            losing_trades=losing_trades,
            win_rate=win_rate,
            total_pnl=round(total_pnl, 2),
            total_pnl_pct=round(total_pnl_pct, 2),
            avg_trade=round(avg_trade, 2),
            avg_win=round(avg_win, 2),
            avg_loss=round(avg_loss, 2),
            profit_factor=round(profit_factor, 2),
            max_drawdown=round(max_drawdown, 2),
            max_drawdown_pct=round(max_drawdown_pct, 2),
            sharpe_ratio=round(sharpe_ratio, 2),
            trades=trades,
            equity_curve=equity_df if not equity_df.empty else pd.DataFrame()
        )
    
    def print_report(self, result: BacktestResult):
        """Print backtest report"""
        print("\n" + "=" * 60)
        print("BACKTEST RESULTS")
        print("=" * 60)
        print(f"Total Trades:     {result.total_trades}")
        print(f"Winning Trades:   {result.winning_trades}")
        print(f"Losing Trades:    {result.losing_trades}")
        print(f"Win Rate:         {result.win_rate:.2f}%")
        print("-" * 60)
        print(f"Total P&L:        ${result.total_pnl:,.2f} ({result.total_pnl_pct:+.2f}%)")
        print(f"Average Trade:    ${result.avg_trade:,.2f}")
        print(f"Average Win:      ${result.avg_win:,.2f}")
        print(f"Average Loss:     ${result.avg_loss:,.2f}")
        print(f"Profit Factor:    {result.profit_factor:.2f}")
        print("-" * 60)
        print(f"Max Drawdown:     ${result.max_drawdown:,.2f} ({result.max_drawdown_pct:.2f}%)")
        print(f"Sharpe Ratio:     {result.sharpe_ratio:.2f}")
        print("=" * 60)
        
        # Print recent trades
        if result.trades:
            print("\nRecent Trades:")
            print("-" * 60)
            for trade in result.trades[-5:]:
                pnl_str = f"${trade.pnl:+.2f}"
                print(f"{trade.entry_date.strftime('%Y-%m-%d')} | "
                      f"{trade.side:4} | {trade.symbol:8} | "
                      f"{trade.entry_price:10.2f} → {trade.exit_price:10.2f} | "
                      f"{pnl_str:12} | {trade.reason}")
        
        print("=" * 60)


# Example usage
if __name__ == "__main__":
    from config.config import TradingConfig, StrategyType
    
    # Create config
    config = TradingConfig()
    config.strategy.strategy_type = StrategyType.TREND_FOLLOWING
    
    # Create backtester
    backtester = Backtester(config)
    
    # Load historical data (you would load real data here)
    # df = pd.read_csv('historical_data.csv')
    
    # Run backtest
    # result = backtester.run_backtest(df, 'BTCUSDT')
    # backtester.print_report(result)