"""
Bybit Trading Bot
================
Main trading bot integrating Bybit API, risk management, and strategies
"""

import os
import time
import json
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
import pandas as pd
import numpy as np
from loguru import logger
from pybit.unified_trading import HTTP
from pybit.exceptions import InvalidRequestError

from .risk_manager import RiskManager, PositionSize, RiskCheck
from .strategies import StrategyManager, TradeSignal, SignalType

@dataclass
class Position:
    """Position data structure"""
    symbol: str
    side: str  # "Buy" or "Sell"
    size: float
    entry_price: float
    leverage: int
    stop_loss: float
    take_profit: float
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    timestamp: str = ""
    order_id: str = ""

@dataclass
class AccountInfo:
    """Account information"""
    total_equity: float
    available_balance: float
    margin_balance: float
    unrealized_pnl: float
    daily_pnl: float

class BybitTrader:
    """Main Bybit Trading Bot"""
    
    def __init__(self, config):
        self.config = config
        self.risk_manager = RiskManager(config)
        self.strategy_manager = StrategyManager(config)
        
        # Initialize Bybit client
        self.client = HTTP(
            testnet=config.testnet,
            api_key=config.api_key,
            api_secret=config.api_secret,
        )
        
        # State
        self.running = False
        self.positions: Dict[str, Position] = {}
        self.order_history: List[Dict] = []
        self.market_data: Dict[str, pd.DataFrame] = {}
        self.last_update = datetime.now()
        
        # Setup logging
        self._setup_logging()
        
        logger.info(f"Bybit Trader initialized - Testnet: {config.testnet}")
    
    def _setup_logging(self):
        """Setup logging configuration"""
        log_format = "{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
        
        # Console logging
        logger.remove()
        logger.add(
            lambda msg: print(msg, end=""),
            format=log_format,
            level=self.config.log_level
        )
        
        # File logging
        if self.config.log_to_file:
            logger.add(
                "logs/trading_bot.log",
                rotation="1 day",
                retention="7 days",
                format=log_format,
                level="DEBUG"
            )
    
    def get_account_info(self) -> AccountInfo:
        """Fetch account information"""
        try:
            response = self.client.get_wallet_balance(accountType="UNIFIED")
            
            if response['retCode'] == 0:
                result = response['result']['list'][0]
                
                return AccountInfo(
                    total_equity=float(result.get('totalEquity', 0)),
                    available_balance=float(result.get('totalAvailableBalance', 0)),
                    margin_balance=float(result.get('totalMarginBalance', 0)),
                    unrealized_pnl=float(result.get('totalPerpUPL', 0)),
                    daily_pnl=0.0  # Will calculate separately
                )
            else:
                logger.error(f"Error fetching account: {response['retMsg']}")
                return AccountInfo(0, 0, 0, 0, 0)
                
        except Exception as e:
            logger.error(f"Exception fetching account: {e}")
            return AccountInfo(0, 0, 0, 0, 0)
    
    def get_klines(self, symbol: str, interval: str = "15", limit: int = 200) -> pd.DataFrame:
        """Fetch candlestick data"""
        try:
            response = self.client.get_kline(
                category="linear" if self.config.trading_mode.value == "linear" else "spot",
                symbol=symbol,
                interval=interval,
                limit=limit
            )
            
            if response['retCode'] == 0:
                data = response['result']['list']
                df = pd.DataFrame(data, columns=[
                    'timestamp', 'open', 'high', 'low', 'close', 'volume', 'turnover'
                ])
                
                # Convert types
                for col in ['open', 'high', 'low', 'close', 'volume', 'turnover']:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
                
                df['timestamp'] = pd.to_datetime(df['timestamp'].astype(int), unit='ms')
                df = df.sort_values('timestamp').reset_index(drop=True)
                
                return df
            else:
                logger.error(f"Error fetching klines: {response['retMsg']}")
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Exception fetching klines: {e}")
            return pd.DataFrame()
    
    def get_positions(self) -> List[Position]:
        """Fetch open positions"""
        try:
            response = self.client.get_positions(
                category="linear" if self.config.trading_mode.value == "linear" else "spot",
                settleCoin="USDT"
            )
            
            positions = []
            if response['retCode'] == 0:
                for pos in response['result']['list']:
                    if float(pos.get('size', 0)) > 0:
                        position = Position(
                            symbol=pos['symbol'],
                            side=pos['side'],
                            size=float(pos['size']),
                            entry_price=float(pos['avgPrice']),
                            leverage=int(pos['leverage']),
                            stop_loss=float(pos.get('stopLoss', 0) or 0),
                            take_profit=float(pos.get('takeProfit', 0) or 0),
                            unrealized_pnl=float(pos.get('unrealisedPnl', 0)),
                            timestamp=pos.get('updatedTime', '')
                        )
                        positions.append(position)
                        self.positions[pos['symbol']] = position
            
            return positions
            
        except Exception as e:
            logger.error(f"Exception fetching positions: {e}")
            return []
    
    def set_leverage(self, symbol: str, leverage: int) -> bool:
        """Set leverage for a symbol"""
        try:
            response = self.client.set_leverage(
                category="linear",
                symbol=symbol,
                buyLeverage=str(leverage),
                sellLeverage=str(leverage)
            )
            
            if response['retCode'] == 0:
                logger.info(f"Leverage set to {leverage}x for {symbol}")
                return True
            else:
                # Might already be set
                if "leverage not modified" in response['retMsg'].lower():
                    return True
                logger.error(f"Error setting leverage: {response['retMsg']}")
                return False
                
        except Exception as e:
            logger.error(f"Exception setting leverage: {e}")
            return False
    
    def place_order(
        self,
        symbol: str,
        side: str,
        qty: float,
        order_type: str = "Limit",
        price: Optional[float] = None,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        reduce_only: bool = False
    ) -> Optional[str]:
        """Place an order"""
        try:
            params = {
                "category": "linear" if self.config.trading_mode.value == "linear" else "spot",
                "symbol": symbol,
                "side": side,
                "orderType": order_type,
                "qty": str(qty),
                "reduceOnly": reduce_only,
                "timeInForce": "GTC"
            }
            
            if price and order_type == "Limit":
                params["price"] = str(price)
            
            if stop_loss:
                params["stopLoss"] = str(stop_loss)
                params["slTriggerBy"] = "LastPrice"
            
            if take_profit:
                params["takeProfit"] = str(take_profit)
                params["tpTriggerBy"] = "LastPrice"
            
            response = self.client.place_order(**params)
            
            if response['retCode'] == 0:
                order_id = response['result']['orderId']
                logger.info(f"Order placed: {order_id} - {side} {qty} {symbol}")
                
                self.order_history.append({
                    'order_id': order_id,
                    'symbol': symbol,
                    'side': side,
                    'qty': qty,
                    'price': price,
                    'timestamp': datetime.now().isoformat(),
                    'status': 'placed'
                })
                
                return order_id
            else:
                logger.error(f"Error placing order: {response['retMsg']}")
                return None
                
        except Exception as e:
            logger.error(f"Exception placing order: {e}")
            return None
    
    def close_position(self, symbol: str) -> bool:
        """Close an open position"""
        try:
            if symbol not in self.positions:
                logger.warning(f"No position found for {symbol}")
                return False
            
            position = self.positions[symbol]
            side = "Sell" if position.side == "Buy" else "Buy"
            
            order_id = self.place_order(
                symbol=symbol,
                side=side,
                qty=position.size,
                order_type="Market",
                reduce_only=True
            )
            
            if order_id:
                logger.info(f"Position closed for {symbol}")
                del self.positions[symbol]
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Exception closing position: {e}")
            return False
    
    def update_trailing_stops(self):
        """Update trailing stops for open positions"""
        for symbol, position in self.positions.items():
            try:
                # Get current price
                ticker = self.client.get_tickers(
                    category="linear",
                    symbol=symbol
                )
                
                if ticker['retCode'] == 0:
                    current_price = float(ticker['result']['list'][0]['lastPrice'])
                    
                    # Calculate trailing stop
                    highest = max(position.entry_price, current_price)
                    lowest = min(position.entry_price, current_price)
                    
                    new_stop = self.risk_manager.calculate_trailing_stop(
                        entry_price=position.entry_price,
                        current_price=current_price,
                        highest_price=highest,
                        lowest_price=lowest,
                        position_side="long" if position.side == "Buy" else "short"
                    )
                    
                    if new_stop and new_stop != position.stop_loss:
                        # Update stop loss
                        self.client.set_trading_stop(
                            category="linear",
                            symbol=symbol,
                            stopLoss=str(new_stop),
                            positionIdx=0
                        )
                        logger.info(f"Trailing stop updated for {symbol}: {new_stop}")
                        
            except Exception as e:
                logger.error(f"Error updating trailing stop for {symbol}: {e}")
    
    def analyze_and_trade(self, symbol: str):
        """Analyze market and execute trade if signal found"""
        try:
            # Get market data
            df = self.get_klines(symbol, self.config.strategy.primary_timeframe)
            
            if df.empty or len(df) < 50:
                logger.warning(f"Insufficient data for {symbol}")
                return
            
            self.market_data[symbol] = df
            
            # Get trading signal
            signal = self.strategy_manager.get_signal(df)
            
            if signal.signal == SignalType.HOLD:
                return
            
            logger.info(f"Signal for {symbol}: {signal.signal.value} (confidence: {signal.confidence:.2f})")
            logger.info(f"Reason: {signal.reason}")
            
            # Check if we already have a position
            if symbol in self.positions:
                logger.info(f"Already have position for {symbol}")
                return
            
            # Risk check
            account = self.get_account_info()
            open_positions = list(self.positions.values())
            
            risk_check = self.risk_manager.check_trade_allowed(
                symbol=symbol,
                account_balance=account.available_balance,
                open_positions=open_positions,
                daily_pnl=self.risk_manager.daily_stats['total_pnl']
            )
            
            if not risk_check.allowed:
                logger.warning(f"Trade blocked by risk manager: {risk_check.reason}")
                return
            
            # Calculate position size
            entry_price = signal.entry_price or df['close'].iloc[-1]
            stop_loss = signal.stop_loss or (entry_price * 0.98)
            
            position_size = self.risk_manager.calculate_position_size(
                entry_price=entry_price,
                stop_loss_price=stop_loss,
                account_balance=account.available_balance,
                symbol=symbol,
                atr=signal.indicators.get('atr') if signal.indicators else None
            )
            
            logger.info(f"Position size: {position_size.size} ({position_size.size_usdt} USDT)")
            
            # Set leverage
            self.set_leverage(symbol, position_size.leverage)
            
            # Place order
            side = "Buy" if signal.signal == SignalType.BUY else "Sell"
            
            order_type = "Market" if self.config.use_market_orders else "Limit"
            price = None if order_type == "Market" else entry_price
            
            order_id = self.place_order(
                symbol=symbol,
                side=side,
                qty=position_size.size,
                order_type=order_type,
                price=price,
                stop_loss=position_size.stop_loss_price,
                take_profit=position_size.take_profit_price
            )
            
            if order_id:
                logger.success(f"Trade executed for {symbol}: {side} {position_size.size}")
                
                # Send notification
                self._send_notification(
                    f"🚀 Trade Executed\n"
                    f"Symbol: {symbol}\n"
                    f"Side: {side}\n"
                    f"Size: {position_size.size} ({position_size.size_usdt} USDT)\n"
                    f"Entry: {entry_price}\n"
                    f"SL: {position_size.stop_loss_price}\n"
                    f"TP: {position_size.take_profit_price}\n"
                    f"Leverage: {position_size.leverage}x"
                )
            
        except Exception as e:
            logger.error(f"Error in analyze_and_trade for {symbol}: {e}")
    
    def _send_notification(self, message: str):
        """Send notification via Telegram"""
        if not self.config.enable_notifications:
            return
        
        try:
            if self.config.telegram_bot_token and self.config.telegram_chat_id:
                import requests
                url = f"https://api.telegram.org/bot{self.config.telegram_bot_token}/sendMessage"
                payload = {
                    "chat_id": self.config.telegram_chat_id,
                    "text": message,
                    "parse_mode": "HTML"
                }
                requests.post(url, json=payload, timeout=5)
        except Exception as e:
            logger.error(f"Error sending notification: {e}")
    
    def run_once(self):
        """Run one iteration of the trading loop"""
        try:
            # Update positions
            self.get_positions()
            
            # Update trailing stops
            if self.config.risk.use_trailing_stop:
                self.update_trailing_stops()
            
            # Analyze each trading pair
            for symbol in self.config.trading_pairs:
                self.analyze_and_trade(symbol)
            
            self.last_update = datetime.now()
            
        except Exception as e:
            logger.error(f"Error in run_once: {e}")
    
    def start(self):
        """Start the trading bot"""
        logger.info("🚀 Starting Bybit Trading Bot...")
        
        # Validate config
        self.config.validate()
        
        # Check account
        account = self.get_account_info()
        logger.info(f"Account Balance: {account.available_balance} USDT")
        
        if account.available_balance < 100:
            logger.warning("Low account balance! Consider depositing more funds.")
        
        self.running = True
        
        # Send startup notification
        self._send_notification(
            f"✅ Trading Bot Started\n"
            f"Testnet: {self.config.testnet}\n"
            f"Balance: {account.available_balance} USDT\n"
            f"Pairs: {', '.join(self.config.trading_pairs)}"
        )
        
        # Main loop
        while self.running:
            self.run_once()
            
            # Sleep between iterations (adjust based on timeframe)
            sleep_seconds = 60  # 1 minute
            if self.config.strategy.primary_timeframe == "5":
                sleep_seconds = 30
            elif self.config.strategy.primary_timeframe in ["15", "30"]:
                sleep_seconds = 60
            elif self.config.strategy.primary_timeframe == "60":
                sleep_seconds = 300
            
            time.sleep(sleep_seconds)
    
    def stop(self):
        """Stop the trading bot"""
        logger.info("🛑 Stopping Bybit Trading Bot...")
        self.running = False
        
        self._send_notification(
            f"🛑 Trading Bot Stopped\n"
            f"Daily P&L: {self.risk_manager.daily_stats['total_pnl']:.2f} USDT"
        )
    
    def get_status(self) -> Dict:
        """Get current bot status"""
        account = self.get_account_info()
        positions = self.get_positions()
        risk_report = self.risk_manager.get_risk_report()
        
        return {
            'running': self.running,
            'testnet': self.config.testnet,
            'last_update': self.last_update.isoformat(),
            'account': asdict(account),
            'positions': [asdict(p) for p in positions],
            'risk': risk_report,
            'trading_pairs': self.config.trading_pairs,
            'strategy': self.config.strategy.strategy_type.value
        }