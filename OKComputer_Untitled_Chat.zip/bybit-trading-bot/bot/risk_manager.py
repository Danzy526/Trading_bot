"""
Risk Management Module
=====================
Handles position sizing, stop-loss calculations, and risk controls
"""

import numpy as np
from typing import Dict, Tuple, Optional
from dataclasses import dataclass
from loguru import logger

@dataclass
class PositionSize:
    """Position sizing result"""
    size: float  # Position size in base currency
    size_usdt: float  # Position size in USDT
    risk_amount: float  # Amount at risk
    leverage: int  # Recommended leverage
    stop_loss_price: float  # Calculated stop loss price
    take_profit_price: float  # Calculated take profit price

@dataclass
class RiskCheck:
    """Risk check result"""
    allowed: bool
    reason: str = ""
    risk_score: float = 0.0

class RiskManager:
    """Advanced Risk Management System"""
    
    def __init__(self, config):
        self.config = config.risk
        self.daily_stats = {
            'starting_balance': 0.0,
            'current_balance': 0.0,
            'total_pnl': 0.0,
            'trades_today': 0,
            'wins': 0,
            'losses': 0
        }
        self.position_history = []
        
    def calculate_position_size(
        self,
        entry_price: float,
        stop_loss_price: float,
        account_balance: float,
        symbol: str,
        atr: Optional[float] = None
    ) -> PositionSize:
        """
        Calculate optimal position size based on risk parameters
        """
        risk_pct = self.config.max_account_risk_per_trade / 100
        risk_amount = account_balance * risk_pct
        
        # Calculate price distance to stop loss
        price_distance = abs(entry_price - stop_loss_price)
        price_distance_pct = price_distance / entry_price
        
        # Adjust for volatility if enabled
        if self.config.adjust_for_volatility and atr:
            volatility_factor = self._calculate_volatility_factor(atr, entry_price)
            position_size = risk_amount / (price_distance * volatility_factor)
            leverage = self._calculate_optimal_leverage(volatility_factor)
        else:
            position_size = risk_amount / price_distance
            leverage = self.config.default_leverage
        
        # Cap leverage at max
        leverage = min(leverage, self.config.max_leverage)
        
        # Calculate USDT value
        size_usdt = position_size * entry_price
        
        # Calculate take profit
        tp_distance = price_distance * (self.config.default_take_profit_pct / self.config.default_stop_loss_pct)
        if entry_price > stop_loss_price:  # Long position
            take_profit_price = entry_price + tp_distance
        else:  # Short position
            take_profit_price = entry_price - tp_distance
        
        return PositionSize(
            size=round(position_size, 6),
            size_usdt=round(size_usdt, 2),
            risk_amount=round(risk_amount, 2),
            leverage=leverage,
            stop_loss_price=round(stop_loss_price, 2),
            take_profit_price=round(take_profit_price, 2)
        )
    
    def calculate_kelly_position_size(
        self,
        win_rate: float,
        avg_win: float,
        avg_loss: float,
        account_balance: float
    ) -> float:
        """
        Calculate position size using Kelly Criterion
        Kelly % = W - [(1 - W) / R]
        where W = win rate, R = win/loss ratio
        """
        if avg_loss == 0:
            return 0.0
        
        win_loss_ratio = avg_win / avg_loss
        kelly_pct = win_rate - ((1 - win_rate) / win_loss_ratio)
        
        # Use fractional Kelly for safety
        kelly_pct *= self.config.kelly_fraction
        
        # Cap at max risk per trade
        max_risk = self.config.max_account_risk_per_trade / 100
        kelly_pct = min(kelly_pct, max_risk)
        
        return account_balance * max(0, kelly_pct)
    
    def check_trade_allowed(
        self,
        symbol: str,
        account_balance: float,
        open_positions: list,
        daily_pnl: float
    ) -> RiskCheck:
        """
        Check if a new trade should be allowed based on risk rules
        """
        # Check daily loss limit
        daily_loss_pct = (daily_pnl / account_balance) * 100 if account_balance > 0 else 0
        if daily_loss_pct <= -self.config.max_daily_loss:
            return RiskCheck(
                allowed=False,
                reason=f"Daily loss limit reached: {daily_loss_pct:.2f}%",
                risk_score=1.0
            )
        
        # Check max concurrent positions
        if len(open_positions) >= self.config.max_concurrent_positions:
            return RiskCheck(
                allowed=False,
                reason=f"Max concurrent positions reached: {len(open_positions)}",
                risk_score=0.8
            )
        
        # Check positions per symbol
        symbol_positions = [p for p in open_positions if p['symbol'] == symbol]
        if len(symbol_positions) >= self.config.max_positions_per_symbol:
            return RiskCheck(
                allowed=False,
                reason=f"Max positions for {symbol} reached",
                risk_score=0.7
            )
        
        # Calculate risk score (lower is better)
        risk_score = self._calculate_risk_score(open_positions, daily_pnl, account_balance)
        
        if risk_score > 0.8:
            return RiskCheck(
                allowed=False,
                reason="Risk score too high",
                risk_score=risk_score
            )
        
        return RiskCheck(allowed=True, risk_score=risk_score)
    
    def calculate_trailing_stop(
        self,
        entry_price: float,
        current_price: float,
        highest_price: float,
        lowest_price: float,
        position_side: str  # "long" or "short"
    ) -> Optional[float]:
        """
        Calculate trailing stop price
        """
        if not self.config.use_trailing_stop:
            return None
        
        activation_pct = self.config.trailing_stop_activation / 100
        trailing_distance_pct = self.config.trailing_stop_distance / 100
        
        if position_side == "long":
            profit_pct = (current_price - entry_price) / entry_price
            if profit_pct >= activation_pct:
                # Activate trailing stop
                trailing_stop = highest_price * (1 - trailing_distance_pct)
                return round(trailing_stop, 2)
        else:  # short
            profit_pct = (entry_price - current_price) / entry_price
            if profit_pct >= activation_pct:
                trailing_stop = lowest_price * (1 + trailing_distance_pct)
                return round(trailing_stop, 2)
        
        return None
    
    def update_daily_stats(self, trade_result: Dict):
        """Update daily trading statistics"""
        self.daily_stats['trades_today'] += 1
        pnl = trade_result.get('realized_pnl', 0)
        self.daily_stats['total_pnl'] += pnl
        
        if pnl > 0:
            self.daily_stats['wins'] += 1
        else:
            self.daily_stats['losses'] += 1
        
        self.position_history.append(trade_result)
        
        # Keep only last 100 trades for calculations
        if len(self.position_history) > 100:
            self.position_history = self.position_history[-100:]
    
    def get_win_rate(self) -> float:
        """Calculate current win rate"""
        total = self.daily_stats['wins'] + self.daily_stats['losses']
        if total == 0:
            return 0.5  # Default to 50%
        return self.daily_stats['wins'] / total
    
    def get_average_win_loss(self) -> Tuple[float, float]:
        """Calculate average win and loss amounts"""
        wins = [p['realized_pnl'] for p in self.position_history if p.get('realized_pnl', 0) > 0]
        losses = [abs(p['realized_pnl']) for p in self.position_history if p.get('realized_pnl', 0) < 0]
        
        avg_win = np.mean(wins) if wins else 0
        avg_loss = np.mean(losses) if losses else 1  # Avoid division by zero
        
        return avg_win, avg_loss
    
    def _calculate_volatility_factor(self, atr: float, price: float) -> float:
        """Calculate volatility adjustment factor"""
        atr_pct = atr / price
        # Higher volatility = smaller position
        if atr_pct > 0.05:  # Very volatile
            return 2.0
        elif atr_pct > 0.03:  # Moderately volatile
            return 1.5
        elif atr_pct > 0.01:  # Normal
            return 1.0
        else:  # Low volatility
            return 0.8
    
    def _calculate_optimal_leverage(self, volatility_factor: float) -> int:
        """Calculate optimal leverage based on volatility"""
        base_leverage = self.config.default_leverage
        adjusted = int(base_leverage / volatility_factor)
        return max(1, min(adjusted, self.config.max_leverage))
    
    def _calculate_risk_score(
        self,
        open_positions: list,
        daily_pnl: float,
        account_balance: float
    ) -> float:
        """Calculate overall risk score (0-1, higher = more risky)"""
        score = 0.0
        
        # Factor 1: Number of open positions
        position_factor = len(open_positions) / self.config.max_concurrent_positions
        score += position_factor * 0.3
        
        # Factor 2: Daily P&L
        if account_balance > 0:
            pnl_factor = abs(daily_pnl) / (account_balance * self.config.max_daily_loss / 100)
            score += min(pnl_factor, 1.0) * 0.4
        
        # Factor 3: Recent performance
        if len(self.position_history) >= 5:
            recent = self.position_history[-5:]
            recent_losses = sum(1 for p in recent if p.get('realized_pnl', 0) < 0)
            streak_factor = recent_losses / 5
            score += streak_factor * 0.3
        
        return min(score, 1.0)
    
    def get_risk_report(self) -> Dict:
        """Generate comprehensive risk report"""
        win_rate = self.get_win_rate()
        avg_win, avg_loss = self.get_average_win_loss()
        
        return {
            'daily_pnl': round(self.daily_stats['total_pnl'], 2),
            'trades_today': self.daily_stats['trades_today'],
            'win_rate': round(win_rate * 100, 2),
            'avg_win': round(avg_win, 2),
            'avg_loss': round(avg_loss, 2),
            'profit_factor': round(avg_win / avg_loss, 2) if avg_loss > 0 else 0,
            'risk_score': round(self._calculate_risk_score([], self.daily_stats['total_pnl'], 
                                                          self.daily_stats['current_balance']), 2)
        }