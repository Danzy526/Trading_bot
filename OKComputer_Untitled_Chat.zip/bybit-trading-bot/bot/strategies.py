"""
Trading Strategies Module
========================
Multiple proven trading strategies for different market conditions
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from loguru import logger
import ta

class SignalType(Enum):
    BUY = "buy"
    SELL = "sell"
    HOLD = "hold"

@dataclass
class TradeSignal:
    """Trading signal result"""
    signal: SignalType
    confidence: float  # 0-1
    entry_price: Optional[float] = None
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    reason: str = ""
    indicators: Dict = None

class BaseStrategy:
    """Base class for all strategies"""
    
    def __init__(self, config):
        self.config = config.strategy
        self.name = "Base Strategy"
    
    def analyze(self, df: pd.DataFrame) -> TradeSignal:
        """Analyze market data and return signal"""
        raise NotImplementedError
    
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate technical indicators"""
        # Add common indicators
        df['ema_fast'] = ta.trend.ema_indicator(df['close'], window=self.config.ema_fast)
        df['ema_slow'] = ta.trend.ema_indicator(df['close'], window=self.config.ema_slow)
        df['ema_trend'] = ta.trend.ema_indicator(df['close'], window=self.config.ema_trend)
        
        df['rsi'] = ta.momentum.rsi(df['close'], window=self.config.rsi_period)
        
        macd = ta.trend.MACD(
            df['close'],
            window_slow=self.config.macd_slow,
            window_fast=self.config.macd_fast,
            window_sign=self.config.macd_signal
        )
        df['macd'] = macd.macd()
        df['macd_signal'] = macd.macd_signal()
        df['macd_histogram'] = macd.macd_diff()
        
        df['atr'] = ta.volatility.average_true_range(df['high'], df['low'], df['close'])
        df['volume_sma'] = df['volume'].rolling(window=20).mean()
        
        # Bollinger Bands
        bb = ta.volatility.BollingerBands(df['close'])
        df['bb_upper'] = bb.bollinger_hband()
        df['bb_lower'] = bb.bollinger_lband()
        df['bb_middle'] = bb.bollinger_mavg()
        df['bb_width'] = bb.bollinger_wband()
        
        return df

class TrendFollowingStrategy(BaseStrategy):
    """
    Trend Following Strategy
    Uses EMA crossovers with trend confirmation
    """
    
    def __init__(self, config):
        super().__init__(config)
        self.name = "Trend Following"
    
    def analyze(self, df: pd.DataFrame) -> TradeSignal:
        df = self.calculate_indicators(df)
        
        if len(df) < 3:
            return TradeSignal(SignalType.HOLD, 0.0, reason="Insufficient data")
        
        current = df.iloc[-1]
        previous = df.iloc[-2]
        
        # Trend direction
        uptrend = current['ema_trend'] > df['ema_trend'].iloc[-5]
        downtrend = current['ema_trend'] < df['ema_trend'].iloc[-5]
        
        # EMA Crossover signals
        golden_cross = (previous['ema_fast'] <= previous['ema_slow'] and 
                       current['ema_fast'] > current['ema_slow'])
        death_cross = (previous['ema_fast'] >= previous['ema_slow'] and 
                      current['ema_fast'] < current['ema_slow'])
        
        # RSI confirmation
        rsi_bullish = current['rsi'] > 50 and current['rsi'] < 70
        rsi_bearish = current['rsi'] < 50 and current['rsi'] > 30
        
        # Volume confirmation
        volume_confirmed = current['volume'] > current['volume_sma'] * 1.2
        
        signal = SignalType.HOLD
        confidence = 0.0
        reason = "No clear signal"
        
        # Buy Signal
        if golden_cross and uptrend and rsi_bullish:
            signal = SignalType.BUY
            confidence = 0.7
            if volume_confirmed:
                confidence = 0.85
            reason = "EMA Golden Cross + Uptrend + RSI Bullish"
        
        # Sell Signal
        elif death_cross and downtrend and rsi_bearish:
            signal = SignalType.SELL
            confidence = 0.7
            if volume_confirmed:
                confidence = 0.85
            reason = "EMA Death Cross + Downtrend + RSI Bearish"
        
        # Calculate levels
        atr = current['atr']
        entry = current['close']
        
        if signal == SignalType.BUY:
            stop_loss = entry - (atr * 1.5)
            take_profit = entry + (atr * 3)
        elif signal == SignalType.SELL:
            stop_loss = entry + (atr * 1.5)
            take_profit = entry - (atr * 3)
        else:
            stop_loss = None
            take_profit = None
        
        return TradeSignal(
            signal=signal,
            confidence=confidence,
            entry_price=round(entry, 2),
            stop_loss=round(stop_loss, 2) if stop_loss else None,
            take_profit=round(take_profit, 2) if take_profit else None,
            reason=reason,
            indicators={
                'ema_fast': round(current['ema_fast'], 2),
                'ema_slow': round(current['ema_slow'], 2),
                'rsi': round(current['rsi'], 2),
                'atr': round(current['atr'], 2)
            }
        )

class RSIMACDStrategy(BaseStrategy):
    """
    RSI + MACD Strategy
    Combines RSI oversold/overbought with MACD momentum
    """
    
    def __init__(self, config):
        super().__init__(config)
        self.name = "RSI + MACD"
    
    def analyze(self, df: pd.DataFrame) -> TradeSignal:
        df = self.calculate_indicators(df)
        
        if len(df) < 3:
            return TradeSignal(SignalType.HOLD, 0.0, reason="Insufficient data")
        
        current = df.iloc[-1]
        previous = df.iloc[-2]
        
        # RSI conditions
        rsi_oversold = current['rsi'] < self.config.rsi_oversold
        rsi_overbought = current['rsi'] > self.config.rsi_overbought
        rsi_rising = current['rsi'] > previous['rsi']
        rsi_falling = current['rsi'] < previous['rsi']
        
        # MACD conditions
        macd_bullish = (previous['macd'] <= previous['macd_signal'] and 
                       current['macd'] > current['macd_signal'])
        macd_bearish = (previous['macd'] >= previous['macd_signal'] and 
                       current['macd'] < current['macd_signal'])
        macd_positive = current['macd'] > 0
        macd_negative = current['macd'] < 0
        
        signal = SignalType.HOLD
        confidence = 0.0
        reason = "No clear signal"
        
        # Buy: RSI oversold + MACD bullish crossover
        if rsi_oversold and macd_bullish and rsi_rising:
            signal = SignalType.BUY
            confidence = 0.8
            reason = "RSI Oversold + MACD Bullish Crossover"
        
        # Sell: RSI overbought + MACD bearish crossover
        elif rsi_overbought and macd_bearish and rsi_falling:
            signal = SignalType.SELL
            confidence = 0.8
            reason = "RSI Overbought + MACD Bearish Crossover"
        
        # Calculate levels
        atr = current['atr']
        entry = current['close']
        
        if signal == SignalType.BUY:
            stop_loss = entry - (atr * 2)
            take_profit = entry + (atr * 4)
        elif signal == SignalType.SELL:
            stop_loss = entry + (atr * 2)
            take_profit = entry - (atr * 4)
        else:
            stop_loss = None
            take_profit = None
        
        return TradeSignal(
            signal=signal,
            confidence=confidence,
            entry_price=round(entry, 2),
            stop_loss=round(stop_loss, 2) if stop_loss else None,
            take_profit=round(take_profit, 2) if take_profit else None,
            reason=reason,
            indicators={
                'rsi': round(current['rsi'], 2),
                'macd': round(current['macd'], 4),
                'macd_signal': round(current['macd_signal'], 4),
                'atr': round(current['atr'], 2)
            }
        )

class BreakoutStrategy(BaseStrategy):
    """
    Breakout Strategy
    Trades breakouts from consolidation with volume confirmation
    """
    
    def __init__(self, config):
        super().__init__(config)
        self.name = "Breakout"
    
    def analyze(self, df: pd.DataFrame) -> TradeSignal:
        df = self.calculate_indicators(df)
        
        if len(df) < self.config.breakout_lookback + 5:
            return TradeSignal(SignalType.HOLD, 0.0, reason="Insufficient data")
        
        current = df.iloc[-1]
        
        # Calculate support and resistance
        lookback = self.config.breakout_lookback
        recent_highs = df['high'].tail(lookback).max()
        recent_lows = df['low'].tail(lookback).min()
        
        # Current price action
        price = current['close']
        
        # Volume confirmation
        volume_confirmed = current['volume'] > current['volume_sma'] * self.config.breakout_volume_factor
        
        # Breakout conditions
        breakout_up = price > recent_highs * 0.995  # Small buffer
        breakout_down = price < recent_lows * 1.005
        
        # Avoid false breakouts - check consolidation
        consolidation_range = (recent_highs - recent_lows) / recent_lows
        is_consolidated = consolidation_range < 0.05  # Less than 5% range
        
        signal = SignalType.HOLD
        confidence = 0.0
        reason = "No breakout detected"
        
        if breakout_up and volume_confirmed:
            signal = SignalType.BUY
            confidence = 0.75 if is_consolidated else 0.6
            reason = f"Upside Breakout with Volume (Range: {consolidation_range:.2%})"
        elif breakout_down and volume_confirmed:
            signal = SignalType.SELL
            confidence = 0.75 if is_consolidated else 0.6
            reason = f"Downside Breakout with Volume (Range: {consolidation_range:.2%})"
        
        # Calculate levels
        atr = current['atr']
        entry = price
        
        if signal == SignalType.BUY:
            stop_loss = recent_lows - (atr * 0.5)
            take_profit = entry + (entry - stop_loss) * 2
        elif signal == SignalType.SELL:
            stop_loss = recent_highs + (atr * 0.5)
            take_profit = entry - (stop_loss - entry) * 2
        else:
            stop_loss = None
            take_profit = None
        
        return TradeSignal(
            signal=signal,
            confidence=confidence,
            entry_price=round(entry, 2),
            stop_loss=round(stop_loss, 2) if stop_loss else None,
            take_profit=round(take_profit, 2) if take_profit else None,
            reason=reason,
            indicators={
                'recent_high': round(recent_highs, 2),
                'recent_low': round(recent_lows, 2),
                'volume_ratio': round(current['volume'] / current['volume_sma'], 2),
                'atr': round(current['atr'], 2)
            }
        )

class ScalpingStrategy(BaseStrategy):
    """
    Scalping Strategy
    Quick trades based on short-term momentum
    """
    
    def __init__(self, config):
        super().__init__(config)
        self.name = "Scalping"
    
    def analyze(self, df: pd.DataFrame) -> TradeSignal:
        df = self.calculate_indicators(df)
        
        if len(df) < 10:
            return TradeSignal(SignalType.HOLD, 0.0, reason="Insufficient data")
        
        current = df.iloc[-1]
        previous = df.iloc[-2]
        
        # Quick EMA cross
        ema_bullish = current['ema_fast'] > current['ema_slow']
        ema_bearish = current['ema_fast'] < current['ema_slow']
        
        # RSI momentum
        rsi_momentum = current['rsi'] - previous['rsi']
        
        # Price momentum
        price_change = (current['close'] - previous['close']) / previous['close'] * 100
        
        # Volume spike
        volume_spike = current['volume'] > current['volume_sma'] * 1.5
        
        signal = SignalType.HOLD
        confidence = 0.0
        reason = "No scalp opportunity"
        
        # Buy: EMA bullish + RSI rising + positive price momentum
        if ema_bullish and rsi_momentum > 2 and price_change > 0.1 and volume_spike:
            signal = SignalType.BUY
            confidence = 0.7
            reason = "Scalp Buy - Momentum + Volume"
        
        # Sell: EMA bearish + RSI falling + negative price momentum
        elif ema_bearish and rsi_momentum < -2 and price_change < -0.1 and volume_spike:
            signal = SignalType.SELL
            confidence = 0.7
            reason = "Scalp Sell - Momentum + Volume"
        
        # Calculate tight levels for scalping
        entry = current['close']
        
        if signal == SignalType.BUY:
            stop_loss = entry * (1 - self.config.scalping_stop_loss / 100)
            take_profit = entry * (1 + self.config.scalping_profit_target / 100)
        elif signal == SignalType.SELL:
            stop_loss = entry * (1 + self.config.scalping_stop_loss / 100)
            take_profit = entry * (1 - self.config.scalping_profit_target / 100)
        else:
            stop_loss = None
            take_profit = None
        
        return TradeSignal(
            signal=signal,
            confidence=confidence,
            entry_price=round(entry, 2),
            stop_loss=round(stop_loss, 2) if stop_loss else None,
            take_profit=round(take_profit, 2) if take_profit else None,
            reason=reason,
            indicators={
                'price_change': round(price_change, 3),
                'rsi_momentum': round(rsi_momentum, 2),
                'volume_spike': volume_spike,
                'ema_bullish': ema_bullish
            }
        )

class StrategyManager:
    """Manages multiple strategies and aggregates signals"""
    
    def __init__(self, config):
        self.config = config
        self.strategies = {
            'trend_following': TrendFollowingStrategy(config),
            'rsi_macd': RSIMACDStrategy(config),
            'breakout': BreakoutStrategy(config),
            'scalping': ScalpingStrategy(config)
        }
        self.active_strategy = self.strategies.get(config.strategy.strategy_type.value, 
                                                   self.strategies['trend_following'])
    
    def get_signal(self, df: pd.DataFrame, strategy_name: Optional[str] = None) -> TradeSignal:
        """Get signal from specified or active strategy"""
        if strategy_name and strategy_name in self.strategies:
            return self.strategies[strategy_name].analyze(df)
        return self.active_strategy.analyze(df)
    
    def get_all_signals(self, df: pd.DataFrame) -> Dict[str, TradeSignal]:
        """Get signals from all strategies"""
        signals = {}
        for name, strategy in self.strategies.items():
            signals[name] = strategy.analyze(df)
        return signals
    
    def get_consensus_signal(self, df: pd.DataFrame) -> TradeSignal:
        """Get consensus signal from multiple strategies"""
        signals = self.get_all_signals(df)
        
        buy_votes = 0
        sell_votes = 0
        total_confidence = 0
        reasons = []
        
        for name, signal in signals.items():
            if signal.signal == SignalType.BUY:
                buy_votes += 1
                total_confidence += signal.confidence
                reasons.append(f"{name}: {signal.reason}")
            elif signal.signal == SignalType.SELL:
                sell_votes += 1
                total_confidence += signal.confidence
                reasons.append(f"{name}: {signal.reason}")
        
        # Need at least 2 strategies agreeing
        if buy_votes >= 2 and buy_votes > sell_votes:
            consensus = SignalType.BUY
            confidence = total_confidence / buy_votes
        elif sell_votes >= 2 and sell_votes > buy_votes:
            consensus = SignalType.SELL
            confidence = total_confidence / sell_votes
        else:
            consensus = SignalType.HOLD
            confidence = 0.0
        
        # Use the strongest signal's levels
        strongest_signal = None
        max_confidence = 0
        for signal in signals.values():
            if signal.confidence > max_confidence:
                max_confidence = signal.confidence
                strongest_signal = signal
        
        return TradeSignal(
            signal=consensus,
            confidence=confidence,
            entry_price=strongest_signal.entry_price if strongest_signal else None,
            stop_loss=strongest_signal.stop_loss if strongest_signal else None,
            take_profit=strongest_signal.take_profit if strongest_signal else None,
            reason=" | ".join(reasons[:3]),
            indicators=strongest_signal.indicators if strongest_signal else {}
        )