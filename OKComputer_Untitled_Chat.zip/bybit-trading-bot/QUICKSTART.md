# Bybit Trading Bot - Quick Start Guide 🚀

## Prerequisites
- Python 3.8+
- Node.js 18+ (for advanced dashboard)
- Bybit account (Testnet recommended for testing)

## Installation (5 minutes)

### 1. Clone and Setup
```bash
cd bybit-trading-bot
chmod +x setup.sh
./setup.sh
```

### 2. Configure API Keys
```bash
# Edit the .env file
nano .env
```

Add your Bybit API credentials:
```
BYBIT_API_KEY=your_api_key_here
BYBIT_API_SECRET=your_api_secret_here
BYBIT_TESTNET=true  # Start with testnet!
```

**Get API Keys:**
- Testnet: https://testnet.bybit.com/app/user/api-management
- Live: https://www.bybit.com/app/user/api-management

### 3. Start the Bot

#### Option A: Bot Only (Terminal)
```bash
source venv/bin/activate
python main.py
```

#### Option B: With Web Dashboard (Recommended)
```bash
source venv/bin/activate
python main.py --dashboard
```

Then open: http://localhost:5000

## First Steps

### 1. Verify Testnet Connection
The bot will show:
```
Mode: Paper Trading (Testnet)
Account Balance: XXXX USDT
```

### 2. Check Dashboard
Open http://localhost:5000 to see:
- Account balance and P&L
- Open positions
- Trading signals
- Risk metrics

### 3. Monitor Signals
The bot will analyze markets and show signals like:
```
Signal for BTCUSDT: buy (confidence: 0.85)
Reason: EMA Golden Cross + Uptrend + RSI Bullish
```

### 4. Let it Trade
When confidence is high enough, the bot will:
- Calculate position size (2% risk)
- Set stop loss and take profit
- Execute the trade
- Update trailing stops

## Configuration

### Change Trading Pairs
Edit `.env`:
```
TRADING_PAIRS=BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT
```

### Change Strategy
```
STRATEGY=trend_following  # Recommended
# Options: trend_following, rsi_macd, breakout, scalping
```

### Adjust Risk
```
MAX_RISK_PER_TRADE=2.0    # 2% per trade
MAX_DAILY_LOSS=5.0        # Stop after 5% loss
MAX_POSITIONS=3           # Max 3 positions
MAX_LEVERAGE=5            # Conservative leverage
```

## Common Commands

```bash
# Start bot
python main.py

# Start with dashboard
python main.py --dashboard

# Interactive setup
python main.py --setup

# Live trading (BE CAREFUL!)
python main.py --mode live

# View logs
tail -f logs/trading_bot.log
```

## Safety Checklist ✅

Before going live:
- [ ] Tested on testnet for at least 1 week
- [ ] Verified API keys have trade permissions only
- [ ] Set MAX_RISK_PER_TRADE to 1-2%
- [ ] Set MAX_DAILY_LOSS to 3-5%
- [ ] Enabled Telegram notifications
- [ ] Understand the strategy being used
- [ ] Have emergency stop plan

## Troubleshooting

### "Cannot connect to trading bot API"
- Make sure you're running: `python main.py --dashboard`
- Check port 5000 is available

### "No trades being executed"
- Check signals in dashboard
- Verify account balance > $100
- Check risk limits aren't blocking

### "API Error"
- Verify API keys are correct
- Check if testnet/mainnet matches
- Ensure API has trade permissions

## Next Steps

1. **Paper Trade** - Run on testnet for 1-2 weeks
2. **Analyze Results** - Check win rate, profit factor
3. **Adjust Settings** - Fine-tune risk parameters
4. **Go Live** - Only with small amounts first
5. **Scale Up** - Gradually increase position sizes

## Support

- Read full documentation: `README.md`
- Check logs: `logs/trading_bot.log`
- Review code: `bot/` directory

---

**⚠️ Remember: Never risk more than you can afford to lose!**