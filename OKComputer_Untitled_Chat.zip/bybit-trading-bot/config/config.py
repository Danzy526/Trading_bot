"""
Bybit Trading Bot Configuration
==============================
All trading parameters and risk management settings
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum

class TradingMode(Enum):
    SPOT = "spot"
    PERPETUAL = "linear"  # USDT Perpetual
    INVERSE = "inverse"   # Inverse Perpetual

class StrategyType(Enum):
    TREND_FOLLOWING = "trend_following"
    BREAKOUT = "breakout"
    GRID = "grid"
    SCALPING = "scalping"
    RSI_MACD = "rsi_macd"

@dataclass
class RiskManagement:
    """Risk Management Configuration"""
    # Account Risk Settings
    max_account_risk_per_trade: float = 2.0  # Max % of account per trade
    max_daily_loss: float = 5.0  # Max % loss per day before stopping
    max_concurrent_positions: int = 3  # Max open positions at once
    max_positions_per_symbol: int = 1  # Max positions per trading pair
    
    # Position Sizing
    position_size_method: str = "risk_based"  # risk_based, fixed, kelly
    fixed_position_size: float = 100.0  # Fixed USDT amount if using fixed
    kelly_fraction: float = 0.25  # Half-Kelly for safety
    
    # Stop Loss & Take Profit
    default_stop_loss_pct: float = 2.0  # Default SL %
    default_take_profit_pct: float = 4.0  # Default TP %
    use_trailing_stop: bool = True
    trailing_stop_activation: float = 1.5  # % profit to activate trailing
    trailing_stop_distance: float = 1.0  # % distance for trailing stop
    
    # Leverage (for perpetual)
    max_leverage: int = 10
    default_leverage: int = 5
    
    # Volatility Adjustment
    adjust_for_volatility: bool = True
    volatility_lookback: int = 20  # Periods for ATR calculation

@dataclass
class StrategyConfig:
    """Trading Strategy Configuration"""
    strategy_type: StrategyType = StrategyType.TREND_FOLLOWING
    
    # Timeframes
    primary_timeframe: str = "15m"
    confirmation_timeframe: str = "1h"
    
    # Trend Following Parameters
    ema_fast: int = 9
    ema_slow: int = 21
    ema_trend: int = 50
    
    # RSI Parameters
    rsi_period: int = 14
    rsi_overbought: float = 70.0
    rsi_oversold: float = 30.0
    
    # MACD Parameters
    macd_fast: int = 12
    macd_slow: int = 26
    macd_signal: int = 9
    
    # Breakout Parameters
    breakout_lookback: int = 20
    breakout_volume_factor: float = 1.5
    
    # Grid Parameters
    grid_levels: int = 5
    grid_spacing_pct: float = 1.0
    grid_investment: float = 500.0
    
    # Scalping Parameters
    scalping_profit_target: float = 0.5
    scalping_stop_loss: float = 0.3

@dataclass
class TradingConfig:
    """Main Trading Configuration"""
    # API Settings
    testnet: bool = True  # Start with testnet!
    api_key: str = ""
    api_secret: str = ""
    
    # Trading Mode
    trading_mode: TradingMode = TradingMode.PERPETUAL
    
    # Trading Pairs
    trading_pairs: List[str] = field(default_factory=lambda: ["BTCUSDT", "ETHUSDT", "SOLUSDT"])
    
    # Risk Management
    risk: RiskManagement = field(default_factory=RiskManagement)
    
    # Strategy
    strategy: StrategyConfig = field(default_factory=StrategyConfig)
    
    # Execution
    use_market_orders: bool = False  # Use limit orders for better fills
    order_timeout_seconds: int = 60
    retry_attempts: int = 3
    
    # Monitoring
    enable_notifications: bool = True
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    
    # Logging
    log_level: str = "INFO"
    log_to_file: bool = True
    
    def validate(self):
        """Validate configuration"""
        if not self.testnet and (not self.api_key or not self.api_secret):
            raise ValueError("API credentials required for live trading!")
        
        if self.risk.max_account_risk_per_trade > 5.0:
            raise ValueError("Max risk per trade should not exceed 5%!")
        
        if self.risk.max_leverage > 20:
            raise ValueError("Max leverage should not exceed 20x for safety!")
        
        return True

# Default configuration instance
default_config = TradingConfig()