#!/bin/bash

# Bybit Trading Bot Setup Script
# ==============================

set -e

echo "=================================="
echo "Bybit Trading Bot Setup"
echo "=================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python version
echo "Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
required_version="3.8"

if [ "$(printf '%s\n' "$required_version" "$python_version" | sort -V | head -n1)" != "$required_version" ]; then 
    echo -e "${RED}Error: Python 3.8 or higher is required${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Python version: $python_version${NC}"

# Check Node.js
echo ""
echo "Checking Node.js..."
if ! command -v node &> /dev/null; then
    echo -e "${RED}Error: Node.js is not installed${NC}"
    echo "Please install Node.js 18 or higher from https://nodejs.org/"
    exit 1
fi

node_version=$(node --version | cut -d'v' -f2)
echo -e "${GREEN}✓ Node.js version: $node_version${NC}"

# Create virtual environment
echo ""
echo "Creating Python virtual environment..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo -e "${GREEN}✓ Virtual environment created${NC}"
else
    echo -e "${YELLOW}Virtual environment already exists${NC}"
fi

# Activate virtual environment
echo ""
echo "Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo ""
echo "Upgrading pip..."
pip install --upgrade pip

# Install Python dependencies
echo ""
echo "Installing Python dependencies..."
pip install -r requirements.txt

echo -e "${GREEN}✓ Python dependencies installed${NC}"

# Install dashboard dependencies
echo ""
echo "Installing dashboard dependencies..."
cd dashboard/app
npm install
cd ../..

echo -e "${GREEN}✓ Dashboard dependencies installed${NC}"

# Create necessary directories
echo ""
echo "Creating directories..."
mkdir -p logs
mkdir -p config

echo -e "${GREEN}✓ Directories created${NC}"

# Copy environment file
echo ""
echo "Setting up configuration..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo -e "${YELLOW}⚠ Please edit .env file with your API credentials${NC}"
else
    echo -e "${YELLOW}.env file already exists${NC}"
fi

# Make main.py executable
chmod +x main.py

echo ""
echo "=================================="
echo -e "${GREEN}Setup completed successfully!${NC}"
echo "=================================="
echo ""
echo "Next steps:"
echo "1. Edit .env file with your Bybit API credentials"
echo "2. Run: source venv/bin/activate"
echo "3. Run: python main.py --setup"
echo ""
echo "Or start directly with:"
echo "  python main.py --dashboard"
echo ""
echo "Get your API keys from:"
echo "  Testnet: https://testnet.bybit.com/app/user/api-management"
echo "  Live:    https://www.bybit.com/app/user/api-management"
echo ""