# Bybit Trading Bot 🤖

A professional, feature-rich cryptocurrency trading bot for Bybit with advanced risk management, multiple trading strategies, and a beautiful web dashboard.

![Trading Bot Dashboard](https://img.shields.io/badge/Dashboard-React%20%2B%20TypeScript-blue)
![Risk Management](https://img.shields.io/badge/Risk-Advanced-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

## Features ✨

### Trading Strategies
- **Trend Following** - EMA crossover with trend confirmation (recommended for beginners)
- **RSI + MACD** - Momentum-based signals with dual confirmation
- **Breakout** - Trades breakouts from consolidation with volume confirmation
- **Scalping** - Quick momentum trades for active markets
- **Consensus Mode** - Combines multiple strategies for higher confidence signals

### Risk Management 🛡️
- **Position Sizing** - Risk-based position sizing (Kelly Criterion option)
- **Stop Loss** - Automatic stop-loss on every trade
- **Take Profit** - Automatic take-profit levels
- **Trailing Stops** - Protect profits as they grow
- **Daily Loss Limits** - Bot stops if daily loss exceeds threshold
- **Max Position Limits** - Prevents over-trading
- **Volatility Adjustment** - Adjusts position size based on market volatility

### Dashboard 📊
- **Real-time Updates** - Live WebSocket connection
- **Account Overview** - Balance, P&L, win rate
- **Position Management** - View and close positions
- **Trading Signals** - See all strategy signals with confidence scores
- **Risk Metrics** - Monitor risk score and limits
- **Mobile Responsive** - Trade on the go

## Quick Start 🚀

### 1. Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/bybit-trading-bot.git
cd bybit-trading-bot

# Install Python dependencies
pip install -r requirements.txt

# Install dashboard dependencies
cd dashboard/app
npm install
```

### 2. Configuration

```bash
# Copy the example environment file
cp .env.example .env

# Edit .env with your API credentials
nano .env
```

### 3. Get Bybit API Keys

1. Log in to [Bybit](https://www.bybit.com/)
2. Go to Account → API Management
3. Create new API key with **Read** and **Trade** permissions
4. For testing, use [Bybit Testnet](https://testnet.bybit.com/)

### 4. Run the Bot

```bash
# Interactive setup (recommended for first run)
python main.py --setup

# Start with web dashboard
python main.py --dashboard

# Or start bot only
python main.py
```

The dashboard will be available at `http://localhost:5000`

## Configuration Options ⚙️

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `BYBIT_API_KEY` | Your Bybit API key | - |
| `BYBIT_API_SECRET` | Your Bybit API secret | - |
| `BYBIT_TESTNET` | Use testnet (paper trading) | `true` |
| `TRADING_MODE` | `spot` or `perpetual` | `perpetual` |
| `TRADING_PAIRS` | Comma-separated list | `BTCUSDT,ETHUSDT` |
| `STRATEGY` | Trading strategy | `trend_following` |
| `MAX_RISK_PER_TRADE` | Max % risk per trade | `2.0` |
| `MAX_DAILY_LOSS` | Max daily loss % | `5.0` |
| `MAX_POSITIONS` | Max concurrent positions | `3` |
| `MAX_LEVERAGE` | Maximum leverage | `10` |

### Trading Strategies

#### Trend Following (Recommended)
Best for: Trending markets, beginners
- Uses EMA 9/21/50 for trend detection
- RSI confirmation (30-70 range)
- Volume confirmation
- Risk/Reward: 1:2

#### RSI + MACD
Best for: Range-bound markets
- RSI overbought/oversold signals
- MACD crossover confirmation
- Good for swing trading
- Risk/Reward: 1:2

#### Breakout
Best for: Volatile markets, news events
- Breaks from 20-period consolidation
- Volume spike confirmation
- Higher risk/reward potential
- Risk/Reward: 1:2 to 1:3

#### Scalping
Best for: High volume, experienced traders
- Quick 0.5% profit targets
- Tight 0.3% stop losses
- Requires active monitoring
- Risk/Reward: 1:1.5

## Risk Management 🛡️

### Position Sizing
The bot uses a risk-based position sizing formula:

```
Position Size = Risk Amount / (Entry Price - Stop Loss)
```

Example:
- Account: $10,000
- Risk per trade: 2% ($200)
- Entry: $50,000
- Stop Loss: $49,000
- Position Size = $200 / $1,000 = 0.02 BTC ($1,000 position)

### Safety Features

1. **Daily Loss Limit** - Bot stops trading if daily loss exceeds threshold
2. **Max Positions** - Limits concurrent positions to prevent overexposure
3. **Volatility Adjustment** - Reduces position size in volatile markets
4. **Trailing Stops** - Locks in profits as they grow
5. **Leverage Limits** - Prevents excessive leverage usage

### Risk Score
The bot calculates a risk score (0-100) based on:
- Number of open positions
- Daily P&L performance
- Recent losing streak
- Market volatility

## API Endpoints 📡

### REST API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/status` | GET | Bot status and overview |
| `/api/account` | GET | Account information |
| `/api/positions` | GET | Open positions |
| `/api/positions/<symbol>/close` | POST | Close position |
| `/api/signals/<symbol>` | GET | Trading signals |
| `/api/risk` | GET | Risk report |
| `/api/bot/start` | POST | Start bot |
| `/api/bot/stop` | POST | Stop bot |

### WebSocket Events

- `status_update` - Real-time bot status updates
- `trade_executed` - New trade notifications
- `position_update` - Position changes

## Project Structure 📁

```
bybit-trading-bot/
├── bot/
│   ├── __init__.py
│   ├── bybit_trader.py      # Main trading bot
│   ├── risk_manager.py       # Risk management
│   └── strategies.py         # Trading strategies
├── config/
│   └── config.py             # Configuration classes
├── api/
│   └── web_api.py            # Flask API
├── dashboard/
│   └── app/                  # React dashboard
│       ├── src/
│       │   ├── App.tsx
│       │   └── App.css
│       └── package.json
├── logs/                     # Trading logs
├── main.py                   # Entry point
├── requirements.txt
├── .env.example
└── README.md
```

## Safety Warnings ⚠️

1. **Always start with testnet** - Practice with fake money first
2. **Never risk more than you can afford to lose**
3. **Monitor the bot regularly** - Don't "set and forget"
4. **Use proper risk management** - Start with 1-2% risk per trade
5. **Keep API keys secure** - Never share or commit them

## Troubleshooting 🔧

### Bot won't start
```bash
# Check API credentials
python -c "from main import create_config_from_env; print(create_config_from_env().validate())"

# Test API connection
python main.py --mode paper
```

### No trades being executed
- Check if signals are being generated: `/api/signals/BTCUSDT`
- Verify risk limits aren't blocking trades
- Ensure sufficient account balance

### Dashboard not loading
- Make sure Flask API is running
- Check port 5000 is available
- Verify CORS settings

## Performance Tips 💡

1. **Use VPS** - Run 24/7 on a cloud server
2. **Multiple Timeframes** - Use 15m for entries, 1h for trend
3. **Market Selection** - Trade high-volume pairs (BTC, ETH)
4. **Regular Monitoring** - Check performance weekly
5. **Backtesting** - Test strategies on historical data

## Contributing 🤝

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

## License 📄

MIT License - See LICENSE file for details

## Disclaimer

This software is for educational purposes only. Cryptocurrency trading carries significant risk. Past performance does not guarantee future results. The authors are not responsible for any financial losses incurred while using this software.

---

**Happy Trading! 🚀**