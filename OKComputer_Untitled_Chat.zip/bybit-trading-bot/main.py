#!/usr/bin/env python3
"""
Bybit Trading Bot - Main Entry Point
====================================
Usage: python main.py [--config CONFIG] [--mode {paper,live}]
"""

import os
import sys
import json
import argparse
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

from config.config import TradingConfig, TradingMode, StrategyType
from bot.bybit_trader import BybitTrader


def create_config_from_env() -> TradingConfig:
    """Create configuration from environment variables"""
    config = TradingConfig()
    
    # API Credentials
    config.testnet = os.getenv('BYBIT_TESTNET', 'true').lower() == 'true'
    config.api_key = os.getenv('BYBIT_API_KEY', '')
    config.api_secret = os.getenv('BYBIT_API_SECRET', '')
    
    # Trading Mode
    mode = os.getenv('TRADING_MODE', 'perpetual')
    config.trading_mode = TradingMode(mode)
    
    # Trading Pairs
    pairs = os.getenv('TRADING_PAIRS', 'BTCUSDT,ETHUSDT,SOLUSDT')
    config.trading_pairs = [p.strip() for p in pairs.split(',')]
    
    # Strategy
    strategy = os.getenv('STRATEGY', 'trend_following')
    config.strategy.strategy_type = StrategyType(strategy)
    
    # Risk Management
    config.risk.max_account_risk_per_trade = float(os.getenv('MAX_RISK_PER_TRADE', '2.0'))
    config.risk.max_daily_loss = float(os.getenv('MAX_DAILY_LOSS', '5.0'))
    config.risk.max_concurrent_positions = int(os.getenv('MAX_POSITIONS', '3'))
    config.risk.max_leverage = int(os.getenv('MAX_LEVERAGE', '10'))
    config.risk.default_leverage = int(os.getenv('DEFAULT_LEVERAGE', '5'))
    config.risk.use_trailing_stop = os.getenv('USE_TRAILING_STOP', 'true').lower() == 'true'
    
    # Notifications
    config.enable_notifications = os.getenv('ENABLE_NOTIFICATIONS', 'false').lower() == 'true'
    config.telegram_bot_token = os.getenv('TELEGRAM_BOT_TOKEN', '')
    config.telegram_chat_id = os.getenv('TELEGRAM_CHAT_ID', '')
    
    return config


def create_config_interactive() -> TradingConfig:
    """Create configuration through interactive prompts"""
    print("=" * 60)
    print("Bybit Trading Bot - Configuration Setup")
    print("=" * 60)
    
    config = TradingConfig()
    
    # Testnet
    testnet = input("Use testnet? (recommended for testing) [Y/n]: ").strip().lower()
    config.testnet = testnet != 'n'
    
    # API Credentials
    print("\n--- API Credentials ---")
    print("Get your API keys from: https://www.bybit.com/app/user/api-management")
    if config.testnet:
        print("Testnet: https://testnet.bybit.com/app/user/api-management")
    
    config.api_key = input("API Key: ").strip()
    config.api_secret = input("API Secret: ").strip()
    
    # Trading Mode
    print("\n--- Trading Mode ---")
    print("1. Spot")
    print("2. Perpetual (USDT-Margined)")
    mode_choice = input("Select mode [2]: ").strip() or "2"
    
    if mode_choice == "1":
        config.trading_mode = TradingMode.SPOT
    else:
        config.trading_mode = TradingMode.PERPETUAL
    
    # Trading Pairs
    print("\n--- Trading Pairs ---")
    pairs = input("Enter trading pairs (comma-separated) [BTCUSDT,ETHUSDT,SOLUSDT]: ").strip()
    config.trading_pairs = [p.strip() for p in (pairs or "BTCUSDT,ETHUSDT,SOLUSDT").split(',')]
    
    # Strategy
    print("\n--- Trading Strategy ---")
    print("1. Trend Following (Recommended for beginners)")
    print("2. RSI + MACD")
    print("3. Breakout")
    print("4. Scalping")
    strategy_choice = input("Select strategy [1]: ").strip() or "1"
    
    strategies = {
        "1": StrategyType.TREND_FOLLOWING,
        "2": StrategyType.RSI_MACD,
        "3": StrategyType.BREAKOUT,
        "4": StrategyType.SCALPING
    }
    config.strategy.strategy_type = strategies.get(strategy_choice, StrategyType.TREND_FOLLOWING)
    
    # Risk Management
    print("\n--- Risk Management ---")
    risk = input("Max risk per trade (% of account) [2.0]: ").strip()
    config.risk.max_account_risk_per_trade = float(risk or "2.0")
    
    daily_loss = input("Max daily loss (%) before stopping [5.0]: ").strip()
    config.risk.max_daily_loss = float(daily_loss or "5.0")
    
    max_positions = input("Max concurrent positions [3]: ").strip()
    config.risk.max_concurrent_positions = int(max_positions or "3")
    
    leverage = input("Max leverage [5]: ").strip()
    config.risk.max_leverage = int(leverage or "5")
    config.risk.default_leverage = config.risk.max_leverage
    
    trailing = input("Use trailing stops? [Y/n]: ").strip().lower()
    config.risk.use_trailing_stop = trailing != 'n'
    
    # Notifications
    print("\n--- Notifications (Optional) ---")
    enable_telegram = input("Enable Telegram notifications? [y/N]: ").strip().lower()
    
    if enable_telegram == 'y':
        config.enable_notifications = True
        config.telegram_bot_token = input("Telegram Bot Token: ").strip()
        config.telegram_chat_id = input("Telegram Chat ID: ").strip()
    
    print("\n" + "=" * 60)
    print("Configuration complete!")
    print("=" * 60)
    
    return config


def save_config(config: TradingConfig, filepath: str = "config/trading_config.json"):
    """Save configuration to file"""
    config_dict = {
        'testnet': config.testnet,
        'trading_mode': config.trading_mode.value,
        'trading_pairs': config.trading_pairs,
        'strategy': config.strategy.strategy_type.value,
        'risk': {
            'max_account_risk_per_trade': config.risk.max_account_risk_per_trade,
            'max_daily_loss': config.risk.max_daily_loss,
            'max_concurrent_positions': config.risk.max_concurrent_positions,
            'max_leverage': config.risk.max_leverage,
            'default_leverage': config.risk.default_leverage,
            'use_trailing_stop': config.risk.use_trailing_stop
        }
    }
    
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w') as f:
        json.dump(config_dict, f, indent=2)
    
    print(f"Configuration saved to {filepath}")


def main():
    parser = argparse.ArgumentParser(description='Bybit Trading Bot')
    parser.add_argument('--config', '-c', help='Path to config file')
    parser.add_argument('--setup', '-s', action='store_true', help='Run interactive setup')
    parser.add_argument('--mode', '-m', choices=['paper', 'live'], 
                       help='Trading mode (paper=testnet, live=real)')
    parser.add_argument('--dashboard', '-d', action='store_true', 
                       help='Start web dashboard')
    
    args = parser.parse_args()
    
    # Load or create configuration
    if args.setup:
        config = create_config_interactive()
        save_config(config)
    elif args.config:
        # Load from JSON file
        with open(args.config, 'r') as f:
            config_data = json.load(f)
        config = TradingConfig()
        # Parse config_data and set values...
        print(f"Loaded configuration from {args.config}")
    else:
        # Try to load from environment
        config = create_config_from_env()
    
    # Override mode if specified
    if args.mode:
        config.testnet = (args.mode == 'paper')
    
    # Validate configuration
    try:
        config.validate()
    except ValueError as e:
        print(f"Configuration error: {e}")
        print("Run with --setup to configure the bot")
        sys.exit(1)
    
    # Start dashboard if requested
    if args.dashboard:
        print("Starting web dashboard...")
        from api.web_api import start_dashboard
        start_dashboard(config)
        return
    
    # Start trading bot
    print("=" * 60)
    print("Bybit Trading Bot")
    print("=" * 60)
    print(f"Mode: {'Paper Trading (Testnet)' if config.testnet else 'LIVE TRADING'}")
    print(f"Trading Pairs: {', '.join(config.trading_pairs)}")
    print(f"Strategy: {config.strategy.strategy_type.value}")
    print(f"Max Risk/Trade: {config.risk.max_account_risk_per_trade}%")
    print(f"Max Leverage: {config.risk.max_leverage}x")
    print("=" * 60)
    
    if not config.testnet:
        print("\n⚠️  WARNING: You are about to trade with REAL MONEY!")
        confirm = input("Type 'LIVE' to confirm: ").strip()
        if confirm != 'LIVE':
            print("Cancelled. Use --mode paper for testnet trading.")
            sys.exit(0)
    
    # Create and start trader
    trader = BybitTrader(config)
    
    try:
        trader.start()
    except KeyboardInterrupt:
        print("\nShutdown requested...")
    finally:
        trader.stop()
        print("Bot stopped. Goodbye!")


if __name__ == "__main__":
    main()